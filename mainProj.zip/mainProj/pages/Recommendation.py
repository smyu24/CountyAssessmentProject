import streamlit as st
def recommendation():
    st.write("RECOMMENDATION PAGE")
    temp="""
    https://github.com/ash2shukla/streamlit-bokeh-events
    This could be used to plot and add interactability with data/figuers 

    https://github.com/tvst/st-annotated-text
    This could be used to annotate text and provide definitions of technical jargon
    """