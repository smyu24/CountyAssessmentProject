import streamlit as st
def settings():
    st.write("HELLOOOOO")